# ساخت HealthBook در Termux

1. ZIP را استخراج کنید.
2. وارد پوشه پروژه شوید.
3. مطمئن شوید Java 17/21 و Android SDK موردنیاز نصب است.
4. Gradle پروژه را با تنظیمات موجود اجرا کنید.

نمونه:

```bash
cd HealthBookAndroid_v1.4
./gradlew assembleDebug
```

اگر Gradle Wrapper کامل در اختیار ندارید، از اسکریپت build محیط Termux خودتان استفاده کنید.

خروجی معمول Debug در مسیر زیر قرار می‌گیرد:

```text
app/build/outputs/apk/debug/app-debug.apk
```
