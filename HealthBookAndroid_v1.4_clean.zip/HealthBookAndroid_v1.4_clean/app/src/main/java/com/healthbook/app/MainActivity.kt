package com.healthbook.app

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser

data class FieldDef(val key:String,val label:String,val multiline:Boolean=false,val numeric:Boolean=false)
data class FormDef(val no:Int,val title:String,val fields:List<FieldDef>)

class DB(ctx:Context){
    private val db=ctx.openOrCreateDatabase("healthbook.db",Context.MODE_PRIVATE,null)
    init{
        db.execSQL("""CREATE TABLE IF NOT EXISTS students(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, grade TEXT, className TEXT, gender TEXT,
            dob TEXT, phone TEXT, nationalCode TEXT, notes TEXT, schoolName TEXT)""")
        try { db.execSQL("ALTER TABLE students ADD COLUMN schoolName TEXT") } catch(_:Exception) {}
        db.execSQL("""CREATE TABLE IF NOT EXISTS records(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            formNo INTEGER NOT NULL, studentId INTEGER DEFAULT 0,
            createdAt TEXT NOT NULL, data TEXT NOT NULL)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS settings(
            key TEXT PRIMARY KEY,value TEXT)""")
    }
    fun exec(s:String,a:Array<String> = emptyArray())=db.execSQL(s,a)
    fun query(s:String,a:Array<String> = emptyArray())=db.rawQuery(s,a)
    fun close()=db.close()
}

class MainActivity:AppCompatActivity(){
    private lateinit var db:DB
    private lateinit var root:LinearLayout
    private lateinit var pageScroll:ScrollView
    private lateinit var pageOuter:LinearLayout
    private val blue=Color.rgb(20,85,140)
    private val forms=buildForms()

    private val createBackup=registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null)backup(u)}
    private val openBackup=registerForActivityResult(ActivityResultContracts.OpenDocument(arrayOf("*/*"))){u->if(u!=null)restore(u)}

    override fun onCreate(b:Bundle?){
        super.onCreate(b); db=DB(this); home()
    }
    override fun onDestroy(){try{db.close()}catch(_:Exception){};super.onDestroy()}

    private fun page(title:String){
        pageOuter=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(18,14,18,0)
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            fitsSystemWindows=true
        }
        val head=TextView(this).apply{
            text=title;textSize=21f;setTextColor(blue);setTypeface(null,Typeface.BOLD)
            gravity=Gravity.CENTER_VERTICAL
        }
        pageOuter.addView(head,LinearLayout.LayoutParams(-1,62))
        pageScroll=ScrollView(this).apply{isFillViewport=true}
        root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(0,0,0,24)
        }
        pageScroll.addView(root,ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT))
        pageOuter.addView(pageScroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(pageOuter)
    }

    private fun button(t:String,action:()->Unit)=Button(this).apply{
        text=t;isAllCaps=false;textSize=15f;setOnClickListener{action()}
    }
    private fun addButton(t:String,action:()->Unit){
        root.addView(button(t,action),LinearLayout.LayoutParams(-1,58).apply{setMargins(0,4,0,4)})
    }
    private fun edit(label:String,numeric:Boolean=false,multi:Boolean=false,parent:ViewGroup=root):EditText{
        parent.addView(TextView(this).apply{text=label;textSize=13f},LinearLayout.LayoutParams(-1,30))
        return EditText(this).apply{
            hint=label;textSize=16f;layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(12,0,12,0)
            if(numeric)inputType=2 or 8192
            if(multi){inputType=1 or 131072;minLines=3;gravity=Gravity.TOP or Gravity.RIGHT}
            parent.addView(this,LinearLayout.LayoutParams(-1,if(multi)105 else 56).apply{setMargins(0,0,0,6)})
        }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun now()=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())

    private fun home(){
        page("دفتر الکترونیک مراقب سلامت")
        addButton("👨‍🎓 پرونده دانش‌آموزان"){students()}
        addButton("📥 ورود گروهی دانش‌آموزان از Excel / CSV"){importStudentsPage()}
        addButton("📋 فرم‌های ۱ تا ۲۹"){formsPage()}
        addButton("📊 گزارش‌ها و آمار"){reports()}
        addButton("💾 پشتیبان‌گیری"){createBackup.launch("healthbook-backup-${SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(Date())}.hb")}
        addButton("♻️ بازیابی پشتیبان"){openBackup.launch(arrayOf("*/*"))}
        root.addView(TextView(this).apply{
            text="\nنسخه 1.4\nآفلاین • SQLite • PDF • Backup/Restore\nورود سریع با Enter"
            textSize=14f
        })
    }

    private fun students(){
        page("پرونده دانش‌آموزان")
        addButton("➕ ثبت دانش‌آموز جدید"){studentEdit(null)}
        val c=db.query("SELECT id,name,grade,className,schoolName FROM students ORDER BY name")
        while(c.moveToNext()){
            val id=c.getLong(0)
            val s="${c.getString(1)} — ${c.getString(2)} / ${c.getString(3)}${if(c.getString(4).orEmpty().isNotBlank())" — ${c.getString(4)}" else ""}"
            addButton(s){studentEdit(id)}
        }
        c.close();addButton("⬅️ بازگشت"){home()}
    }

    private fun studentEdit(id:Long?){
        page(if(id==null)"دانش‌آموز جدید" else "ویرایش دانش‌آموز")
        var old=Array(9){""}
        if(id!=null){
            val c=db.query("SELECT name,grade,className,gender,dob,phone,nationalCode,notes,schoolName FROM students WHERE id=?",arrayOf("$id"))
            if(c.moveToFirst())for(i in 0..8)old[i]=c.getString(i)?:""
            c.close()
        }
        val e1=edit("نام و نام خانوادگی");e1.setText(old[0])
        val e2=edit("پایه");e2.setText(old[1])
        val e3=edit("کلاس");e3.setText(old[2])
        val e4=edit("جنسیت");e4.setText(old[3])
        val e5=edit("تاریخ تولد (روز/ماه/سال)");e5.setText(old[4])
        val e6=edit("شماره تماس");e6.setText(old[5])
        val e7=edit("کد ملی");e7.setText(old[6])
        val e8=edit("توضیحات",multi=true);e8.setText(old[7])
        val e9=edit("نام مدرسه");e9.setText(old[8])
        addButton("💾 ذخیره"){
            if(e1.text.isBlank()){toast("نام را وارد کنید");return@addButton}
            val a=arrayOf(e1.text.toString(),e2.text.toString(),e3.text.toString(),e4.text.toString(),e5.text.toString(),e6.text.toString(),e7.text.toString(),e8.text.toString(),e9.text.toString())
            try{
                if(id==null)db.exec("INSERT INTO students(name,grade,className,gender,dob,phone,nationalCode,notes,schoolName) VALUES(?,?,?,?,?,?,?,?,?)",a)
                else db.exec("UPDATE students SET name=?,grade=?,className=?,gender=?,dob=?,phone=?,nationalCode=?,notes=?,schoolName=? WHERE id=?",a + "$id")
                toast("ذخیره شد");students()
            }catch(e:Exception){toast("خطا: ${e.message}")}
        }
        if(id!=null)addButton("🗑 حذف دانش‌آموز"){
            db.exec("DELETE FROM students WHERE id=?",arrayOf("$id"))
            db.exec("DELETE FROM records WHERE studentId=?",arrayOf("$id"))
            students()
        }
        addButton("⬅️ بازگشت"){students()}
    }

    private data class ImportedStudent(val name:String,val classText:String,val nationalCode:String,val school:String)

    private val importPicker=registerForActivityResult(ActivityResultContracts.OpenDocument()){u->
        if(u!=null) try { previewImport(u) } catch(e:Exception){ toast("خطا در خواندن فایل: ${e.message}") }
    }

    private fun importStudentsPage(){
        page("ورود گروهی دانش‌آموزان")
        root.addView(TextView(this).apply{
            text="فایل CSV یا Excel (.xlsx) را انتخاب کنید.\nفرمت ساده پیشنهادی: نام | کلاس | کدملی | مدرسه\nمثال: رضا نعمتی | چهارم دو | ۱۲۳۴۵۶۷۸۹۰ | مدرسه فلان\nفایل‌های دارای عنوان ستون هم به‌صورت خودکار تشخیص داده می‌شوند."
            textSize=15f
        },LinearLayout.LayoutParams(-1,190))
        addButton("📂 انتخاب فایل CSV / Excel"){
            importPicker.launch(arrayOf("text/*","text/csv","application/csv","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","*/*"))
        }
        addButton("⬅️ بازگشت"){home()}
    }

    private fun previewImport(uri:Uri){
        val rows=readStudentFile(uri)
        if(rows.isEmpty()){toast("دانش‌آموزی در فایل پیدا نشد");return}
        val sample=rows.take(8).joinToString("\n"){ "${it.name} — ${it.classText} — ${it.nationalCode} — ${it.school}" }
        AlertDialog.Builder(this)
            .setTitle("پیش‌نمایش ورود")
            .setMessage("تعداد رکورد قابل ورود: ${rows.size}\n\n$sample${if(rows.size>8)"\n..." else ""}")
            .setNegativeButton("انصراف",null)
            .setPositiveButton("ورود همه") { _,_-> importStudents(rows) }
            .show()
    }

    private fun importStudents(rows:List<ImportedStudent>){
        var inserted=0;var updated=0;var skipped=0
        try{
            db.exec("BEGIN")
            rows.forEach{r->
                if(r.name.isBlank()){skipped++;return@forEach}
                val gc=parseGradeClass(r.classText)
                val national=normalizeDigits(r.nationalCode).filter{it.isDigit()}
                val c=if(national.isNotBlank()) db.query("SELECT id FROM students WHERE nationalCode=? LIMIT 1",arrayOf(national)) else null
                val found=if(c!=null && c.moveToFirst())c.getLong(0) else 0L
                c?.close()
                if(found>0){
                    db.exec("UPDATE students SET name=?,grade=?,className=?,nationalCode=?,schoolName=? WHERE id=?",arrayOf(r.name,gc.first,gc.second,national,r.school,"$found"));updated++
                }else{
                    db.exec("INSERT INTO students(name,grade,className,gender,dob,phone,nationalCode,notes,schoolName) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(r.name,gc.first,gc.second,"","","",national,"",r.school));inserted++
                }
            }
            db.exec("COMMIT")
            toast("ورود کامل شد\nجدید: $inserted\nبه‌روزرسانی: $updated\nرد شده: $skipped")
            students()
        }catch(e:Exception){
            try{db.exec("ROLLBACK")}catch(_:Exception){}
            toast("خطا در ورود: ${e.message}")
        }
    }

    private fun parseGradeClass(s:String):Pair<String,String>{
        val x=s.trim().replace(Regex("\\s+")," ")
        if(x.isBlank())return "" to ""
        val parts=x.split(" ",limit=2)
        return if(parts.size==2) parts[0] to parts[1] else "" to x
    }

    private fun normalizeDigits(s:String):String=s.map{
        when(it){
            in '۰'..'۹' -> ('0'.code+(it-'۰')).toChar()
            in '٠'..'٩' -> ('0'.code+(it-'٠')).toChar()
            else -> it
        }
    }.joinToString("")

    private fun readStudentFile(uri:Uri):List<ImportedStudent>{
        val bytes=contentResolver.openInputStream(uri)!!.use{it.readBytes()}
        return if(bytes.size>=2 && bytes[0].toInt()==0x50 && bytes[1].toInt()==0x4B) readXlsx(bytes)
        else readCsv(String(bytes,Charsets.UTF_8))
    }

    private fun readCsv(text:String):List<ImportedStudent>{
        val lines=text.replace("\r\n","\n").replace('\r','\n').split('\n').filter{it.isNotBlank()}
        if(lines.isEmpty())return emptyList()
        val delimiter=listOf('|','\t',';',',').maxByOrNull{d->lines.first().count{it==d}} ?: '|'
        val all=lines.map{parseCsvLine(it,delimiter)}
        val first=all.first().map{normalizeHeader(it)}
        val hasHeader=first.any{it in setOf("name","fullname","studentname","class","gradeclass","nationalcode","school","schoolname","نام","نامونامخانوادگی","کلاس","کدملی","مدرسه")}
        val start=if(hasHeader)1 else 0
        val ni=findHeader(first,setOf("name","fullname","studentname","نام","نامونامخانوادگی"),0)
        val ci=findHeader(first,setOf("class","gradeclass","کلاس","پایهکلاس"),1)
        val ki=findHeader(first,setOf("nationalcode","code","کدملی"),2)
        val si=findHeader(first,setOf("school","schoolname","مدرسه","ناممدرسه"),3)
        return all.drop(start).mapNotNull{row->
            val name=cell(row,ni);val cl=cell(row,ci);val nc=cell(row,ki);val school=cell(row,si)
            if(name.isBlank())null else ImportedStudent(name,cl,nc,school)
        }
    }

    private fun parseCsvLine(line:String,delimiter:Char):List<String>{
        val out=mutableListOf<String>();val sb=StringBuilder();var quoted=false;var i=0
        while(i<line.length){
            val ch=line[i]
            if(ch=='"'){
                if(quoted&&i+1<line.length&&line[i+1]=='"'){sb.append('"');i++}else quoted=!quoted
            }else if(ch==delimiter&&!quoted){out+=sb.toString().trim();sb.clear()}else sb.append(ch)
            i++
        }
        out+=sb.toString().trim();return out
    }

    private fun normalizeHeader(s:String)=normalizeDigits(s).trim().lowercase(Locale.ROOT).replace(" ","").replace("_","").replace("-","")
    private fun findHeader(headers:List<String>,names:Set<String>,fallback:Int):Int{
        val i=headers.indexOfFirst{h->names.any{n->h==normalizeHeader(n)}}
        return if(i>=0)i else fallback
    }
    private fun cell(row:List<String>,i:Int)=if(i>=0&&i<row.size)row[i].trim() else ""

    private fun readXlsx(bytes:ByteArray):List<ImportedStudent>{
        val entries=HashMap<String,ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use{z->
            var e=z.nextEntry
            while(e!=null){
                if(!e.isDirectory&&(e.name=="xl/sharedStrings.xml"||e.name=="xl/worksheets/sheet1.xml"))entries[e.name]=z.readBytes()
                e=z.nextEntry
            }
        }
        val shared=entries["xl/sharedStrings.xml"]?.let{parseSharedStrings(it)}?:emptyList()
        val sheet=entries["xl/worksheets/sheet1.xml"]?:return emptyList()
        val rows=parseSheetRows(sheet,shared)
        if(rows.isEmpty())return emptyList()
        val first=rows.first().map{normalizeHeader(it)}
        val hasHeader=first.any{it in setOf("name","fullname","studentname","class","gradeclass","nationalcode","school","schoolname","نام","کدملی","کلاس","مدرسه")}
        val start=if(hasHeader)1 else 0
        val ni=findHeader(first,setOf("name","fullname","studentname","نام","نامونامخانوادگی"),0)
        val ci=findHeader(first,setOf("class","gradeclass","کلاس","پایهکلاس"),1)
        val ki=findHeader(first,setOf("nationalcode","code","کدملی"),2)
        val si=findHeader(first,setOf("school","schoolname","مدرسه","ناممدرسه"),3)
        return rows.drop(start).mapNotNull{r->
            val n=cell(r,ni);if(n.isBlank())null else ImportedStudent(n,cell(r,ci),cell(r,ki),cell(r,si))
        }
    }

    private fun parseSharedStrings(bytes:ByteArray):List<String>{
        val fixed=mutableListOf<String>();val p=android.util.Xml.newPullParser();p.setInput(ByteArrayInputStream(bytes),"UTF-8")
        var inSi=false;var sb=StringBuilder()
        while(p.eventType!=XmlPullParser.END_DOCUMENT){
            if(p.eventType==XmlPullParser.START_TAG&&p.name=="si"){inSi=true;sb=StringBuilder()}
            else if(inSi&&p.eventType==XmlPullParser.START_TAG&&p.name=="t"){p.next();if(p.eventType==XmlPullParser.TEXT)sb.append(p.text)}
            else if(inSi&&p.eventType==XmlPullParser.END_TAG&&p.name=="si"){fixed+=sb.toString();inSi=false}
            p.next()
        }
        return fixed
    }

    private fun parseSheetRows(bytes:ByteArray,shared:List<String>):List<List<String>>{
        val out=mutableListOf<List<String>>();val p=android.util.Xml.newPullParser();p.setInput(ByteArrayInputStream(bytes),"UTF-8")
        var row=mutableListOf<String>();var currentCol=0;var value="";var type="";var cellRef=""
        while(p.eventType!=XmlPullParser.END_DOCUMENT){
            if(p.eventType==XmlPullParser.START_TAG){
                when(p.name){
                    "row"->row=mutableListOf()
                    "c"->{cellRef=p.getAttributeValue(null,"r") ?: "";type=p.getAttributeValue(null,"t") ?: "";value="";currentCol=columnIndex(cellRef)}
                    "v","t"->{p.next();if(p.eventType==XmlPullParser.TEXT)value=p.text}
                }
            }else if(p.eventType==XmlPullParser.END_TAG&&p.name=="c"){
                while(row.size<=currentCol)row.add("")
                row[currentCol]=if(type=="s")shared.getOrNull(value.toIntOrNull()?:-1)?:"" else value
            }else if(p.eventType==XmlPullParser.END_TAG&&p.name=="row"){
                if(row.any{it.isNotBlank()})out+=row
            }
            p.next()
        }
        return out
    }

    private fun columnIndex(ref:String):Int{
        val letters=ref.takeWhile{it.isLetter()};var n=0
        for(c in letters)n=n*26+(c.uppercaseChar()-'A'+1)
        return n-1
    }

    private fun formsPage(){
        page("فرم‌های دفتر")
        addButton("🩺 فرم ۱۹ — دفتر گروهی معاینات یک کلاس"){form19Group()}
        addButton("👤 فرم ۱۹ — ثبت/ویرایش انفرادی"){form19Individual()}
        forms.filter{it.no!=19}.forEach{f->addButton("فرم ${f.no} — ${f.title}"){formPage(f)}}
        addButton("⬅️ بازگشت"){home()}
    }

    private data class ExamFieldViews(
        val dob:EditText,val age:EditText,val height:EditText,val weight:EditText,val bmi:EditText,
        val visionR:EditText,val visionL:EditText,val visionBoth:EditText,
        val hearingR:EditText,val hearingL:EditText,val dentalPermanent:EditText,val dentalMilk:EditText,
        val gum:EditText,val posture:EditText,val nutrition:EditText
    )

    private fun examFields(prefix:String="",parent:ViewGroup=root):ExamFieldViews{
        val dob=edit("${prefix}تاریخ تولد (روز/ماه/سال)",parent=parent)
        val age=edit("${prefix}سن",numeric=true,parent=parent)
        val height=edit("${prefix}قد (cm)",numeric=true,parent=parent)
        val weight=edit("${prefix}وزن (kg)",numeric=true,parent=parent)
        val bmi=edit("${prefix}BMI",parent=parent)
        bmi.isEnabled=false
        val visionR=edit("${prefix}بینایی چشم راست",parent=parent)
        val visionL=edit("${prefix}بینایی چشم چپ",parent=parent)
        val visionBoth=edit("${prefix}بینایی هر دو چشم",parent=parent)
        val hearingR=edit("${prefix}شنوایی گوش راست",parent=parent)
        val hearingL=edit("${prefix}شنوایی گوش چپ",parent=parent)
        val dentalPermanent=edit("${prefix}دهان و دندان — دائمی: پرشده/کشیده/پوسیده",multi=true,parent=parent)
        val dentalMilk=edit("${prefix}دهان و دندان — شیری: پرشده/کشیده/پوسیده",multi=true,parent=parent)
        val gum=edit("${prefix}لثه",parent=parent)
        val posture=edit("${prefix}اختلالات قامتی",parent=parent)
        val nutrition=edit("${prefix}کمبودهای تغذیه‌ای",parent=parent)
        fun calc(){
            val h=height.text.toString().toDoubleOrNull(); val w=weight.text.toString().toDoubleOrNull()
            if(h!=null&&w!=null&&h>0) bmi.setText(String.format(Locale.US,"%.2f",w/((h/100)*(h/100))))
        }
        height.setOnFocusChangeListener{_,has->if(!has)calc()}
        weight.setOnFocusChangeListener{_,has->if(!has)calc()}
        return ExamFieldViews(dob,age,height,weight,bmi,visionR,visionL,visionBoth,hearingR,hearingL,dentalPermanent,dentalMilk,gum,posture,nutrition)
    }

    private fun examToJson(className:String,date:String,name:String,v:ExamFieldViews)=JSONObject().apply{
        put("class",className);put("date",date);put("name",name)
        put("dob",v.dob.text.toString());put("age",v.age.text.toString());put("height",v.height.text.toString());put("weight",v.weight.text.toString());put("bmi",v.bmi.text.toString())
        put("visionR",v.visionR.text.toString());put("visionL",v.visionL.text.toString());put("visionBoth",v.visionBoth.text.toString())
        put("hearingR",v.hearingR.text.toString());put("hearingL",v.hearingL.text.toString())
        put("dentalPermanent",v.dentalPermanent.text.toString());put("dentalMilk",v.dentalMilk.text.toString());put("gum",v.gum.text.toString());put("posture",v.posture.text.toString());put("nutrition",v.nutrition.text.toString())
    }

    private fun setExamFromJson(o:JSONObject,v:ExamFieldViews){
        v.dob.setText(o.optString("dob"));v.age.setText(o.optString("age"));v.height.setText(o.optString("height"));v.weight.setText(o.optString("weight"));v.bmi.setText(o.optString("bmi"))
        v.visionR.setText(o.optString("visionR"));v.visionL.setText(o.optString("visionL"));v.visionBoth.setText(o.optString("visionBoth"));v.hearingR.setText(o.optString("hearingR"));v.hearingL.setText(o.optString("hearingL"))
        v.dentalPermanent.setText(o.optString("dentalPermanent"));v.dentalMilk.setText(o.optString("dentalMilk"));v.gum.setText(o.optString("gum"));v.posture.setText(o.optString("posture"));v.nutrition.setText(o.optString("nutrition"))
    }

    private fun hasExamData(v:ExamFieldViews):Boolean=listOf(v.dob,v.age,v.height,v.weight,v.visionR,v.visionL,v.visionBoth,v.hearingR,v.hearingL,v.dentalPermanent,v.dentalMilk,v.gum,v.posture,v.nutrition).any{it.text.toString().isNotBlank()}

    private fun saveForm19Record(studentId:Long,data:JSONObject,updateLatest:Boolean=true){
        if(updateLatest){
            val c=db.query("SELECT id FROM records WHERE formNo=19 AND studentId=? ORDER BY id DESC LIMIT 1",arrayOf("$studentId"))
            val id=if(c.moveToFirst())c.getLong(0) else 0L;c.close()
            if(id>0){db.exec("UPDATE records SET createdAt=?,data=? WHERE id=?",arrayOf(now(),data.toString(),"$id"));return}
        }
        db.exec("INSERT INTO records(formNo,studentId,createdAt,data) VALUES(19,?,?,?)",arrayOf("$studentId",now(),data.toString()))
    }

    private fun form19Group(){
        page("فرم ۱۹ — دفتر گروهی معاینات")
        val classEdit=edit("کلاس (مثلاً چهارم دو)")
        val dateEdit=edit("تاریخ معاینه")
        addButton("👥 نمایش دانش‌آموزان این کلاس"){
            val cls=classEdit.text.toString().trim()
            if(cls.isBlank()){toast("کلاس را وارد کنید");return@addButton}
            form19GroupRoster(cls,dateEdit.text.toString())
        }
        addButton("👤 رفتن به ثبت انفرادی"){form19Individual()}
        addButton("⬅️ بازگشت"){formsPage()}
    }

    private data class GroupRow(val id:Long,val name:String,val card:LinearLayout,val views:ExamFieldViews)

    private fun form19GroupRoster(cls:String,date:String){
        page("فرم ۱۹ — $cls${if(date.isNotBlank())" / $date" else ""}")
        val c=db.query("SELECT id,name,grade,className FROM students WHERE className=? ORDER BY name",arrayOf(cls))
        val rows=mutableListOf<GroupRow>()
        while(c.moveToNext()){
            val id=c.getLong(0);val name=c.getString(1);val grade=c.getString(2);val klass=c.getString(3)
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,10,10,10);setBackgroundColor(Color.rgb(245,248,250))}
            card.addView(TextView(this).apply{text="👤 $name   |   $grade / $klass";textSize=17f;setTypeface(null,Typeface.BOLD)})
            val v=examFields("$name — ",card)
            val q=db.query("SELECT data FROM records WHERE formNo=19 AND studentId=? ORDER BY id DESC LIMIT 1",arrayOf("$id"))
            if(q.moveToFirst()) setExamFromJson(JSONObject(q.getString(0)),v)
            q.close()
            rows+=GroupRow(id,name,card,v)
        }
        c.close()
        if(rows.isEmpty()){toast("دانش‌آموزی با این کلاس پیدا نشد");form19Group();return}
        addButton("💾 ذخیره همه معاینات ثبت‌شده") {
            var saved=0
            rows.forEach{r->if(hasExamData(r.views)){saveForm19Record(r.id,examToJson(cls,date,r.name,r.views));saved++}}
            toast("$saved پرونده ذخیره/به‌روزرسانی شد. دانش‌آموز غایب بدون اطلاعات باقی می‌ماند.")
        }
        addButton("⬅️ بازگشت به فرم‌ها"){formsPage()}
        rows.forEach{r->root.addView(r.card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,14)})}
    }

    private fun clearExam(v:ExamFieldViews){
        listOf(v.dob,v.age,v.height,v.weight,v.bmi,v.visionR,v.visionL,v.visionBoth,v.hearingR,v.hearingL,v.dentalPermanent,v.dentalMilk,v.gum,v.posture,v.nutrition).forEach{it.text.clear()}
    }

    private fun form19Individual(){
        page("فرم ۱۹ — ثبت / ویرایش انفرادی")
        val c=db.query("SELECT id,name,grade,className FROM students ORDER BY className,name")
        val ids=mutableListOf<Long>();val names=mutableListOf<String>("انتخاب دانش‌آموز")
        while(c.moveToNext()){ids+=c.getLong(0);names+="${c.getString(1)} — ${c.getString(2)} / ${c.getString(3)}"};c.close()
        val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names);root.addView(sp,LinearLayout.LayoutParams(-1,58))
        val date=edit("تاریخ معاینه");val v=examFields()
        fun load(){
            val pos=sp.selectedItemPosition;if(pos<=0){clearExam(v);return}
            val id=ids[pos-1];val q=db.query("SELECT data FROM records WHERE formNo=19 AND studentId=? ORDER BY id DESC LIMIT 1",arrayOf("$id"))
            if(q.moveToFirst())setExamFromJson(JSONObject(q.getString(0)),v) else clearExam(v);q.close()
        }
        sp.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){ } override fun onItemSelected(p:AdapterView<*>?,x:View?,pos:Int,id:Long){load()}})
        addButton("💾 ذخیره این دانش‌آموز"){
            val pos=sp.selectedItemPosition;if(pos<=0){toast("دانش‌آموز را انتخاب کنید");return@addButton}
            saveForm19Record(ids[pos-1],examToJson("",date.text.toString(),names[pos].substringBefore(" — "),v));toast("معاینه ذخیره شد")
        }
        addButton("🆕 پاک کردن فرم برای ثبت جدید"){clearExam(v)}
        addButton("⬅️ بازگشت"){formsPage()}
    }

    private fun formPage(f:FormDef){
        page("فرم ${f.no} — ${f.title}")
        var selectedStudent=0L
        if(f.no in setOf(10,11,12,13,16,18,19,20,21,22,26,28)){
            val c=db.query("SELECT id,name,grade,className,schoolName FROM students ORDER BY name")
            val ids=mutableListOf<Long>();val names=mutableListOf("بدون اتصال")
            while(c.moveToNext()){ids+=c.getLong(0);names+="${c.getString(1)} — ${c.getString(2)}/${c.getString(3)}"}
            c.close()
            val sp=Spinner(this)
            sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names)
            root.addView(TextView(this).apply{text="دانش‌آموز مرتبط (اختیاری)";textSize=13f})
            root.addView(sp,LinearLayout.LayoutParams(-1,55))
            sp.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(p:AdapterView<*>?) {}
                override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){selectedStudent=if(pos==0)0 else ids[pos-1]}
            })
        }
        val es=f.fields.mapIndexed{idx,fd->
            edit(fd.label,fd.numeric,fd.multiline).also{e->
                e.imeOptions=if(idx==f.fields.lastIndex)EditorInfo.IME_ACTION_DONE else EditorInfo.IME_ACTION_NEXT
            }
        }
        for(i in es.indices.dropLast(1))es[i].setOnEditorActionListener{_,a,_->
            if(a==EditorInfo.IME_ACTION_NEXT){es[i+1].requestFocus();true}else false
        }
        if(es.isNotEmpty())es.last().setOnEditorActionListener{_,a,_->
            if(a==EditorInfo.IME_ACTION_DONE){save(f,es,selectedStudent);true}else false
        }
        if(f.no==19){
            val h=es.find{f.fields[es.indexOf(it)].key=="height"}
            val w=es.find{f.fields[es.indexOf(it)].key=="weight"}
            val bmi=es.find{f.fields[es.indexOf(it)].key=="bmi"}
            fun calc(){
                val hh=h?.text.toString().toDoubleOrNull()
                val ww=w?.text.toString().toDoubleOrNull()
                if(hh!=null&&ww!=null&&hh>0){bmi?.setText(String.format(Locale.US,"%.2f",ww/((hh/100)*(hh/100))))}
            }
            h?.setOnFocusChangeListener{_,has->if(!has)calc()}
            w?.setOnFocusChangeListener{_,has->if(!has)calc()}
        }
        addButton("💾 ذخیره"){save(f,es,selectedStudent)}
        addButton("📄 PDF رکوردهای این فرم"){formPdf(f)}
        addButton("⬅️ بازگشت"){formsPage()}
    }

    private fun save(f:FormDef,es:List<EditText>,sid:Long){
        try{
            val o=JSONObject()
            f.fields.forEachIndexed{i,fd->o.put(fd.key,es[i].text.toString())}
            db.exec("INSERT INTO records(formNo,studentId,createdAt,data) VALUES(?,?,?,?)",
                arrayOf("${f.no}","$sid",now(),o.toString()))
            toast("ثبت شد")
            es.forEach{it.text.clear()}
            es.firstOrNull()?.requestFocus()
        }catch(e:Exception){toast("خطا در ذخیره: ${e.message}")}
    }

    private fun reports(){
        page("گزارش‌ها و آمار")
        addButton("📄 گزارش دانش‌آموزان"){studentReport()}
        addButton("📈 داشبورد آماری مدرسه"){dashboard()}
        forms.forEach{f->addButton("فرم ${f.no} — گزارش PDF"){formPdf(f)}}
        addButton("⬅️ بازگشت"){home()}
    }

    private fun studentReport(){
        page("گزارش دانش‌آموزان")
        val g=edit("پایه — خالی = همه");val cl=edit("کلاس — خالی = همه")
        addButton("📄 ساخت PDF"){
            val w=mutableListOf<String>();val a=mutableListOf<String>()
            if(g.text.isNotBlank()){w+="grade=?";a+=g.text.toString()}
            if(cl.text.isNotBlank()){w+="className=?";a+=cl.text.toString()}
            val sql="SELECT name,grade,className,gender,dob,phone FROM students"+if(w.isEmpty())"" else " WHERE "+w.joinToString(" AND ")
            val c=db.query(sql,a.toTypedArray());val lines=mutableListOf("گزارش دانش‌آموزان")
            while(c.moveToNext())lines+="نام: ${c.getString(0)} | پایه: ${c.getString(1)} | کلاس: ${c.getString(2)} | جنسیت: ${c.getString(3)} | تولد: ${c.getString(4)}"
            c.close();makePdf("گزارش دانش‌آموزان",lines)
        }
        addButton("⬅️ بازگشت"){reports()}
    }

    private fun dashboard(){
        page("داشبورد آماری")
        val cs=db.query("SELECT COUNT(*) FROM students");val n=if(cs.moveToFirst())cs.getInt(0) else 0;cs.close()
        val cr=db.query("SELECT formNo,COUNT(*) FROM records GROUP BY formNo ORDER BY formNo")
        val lines=mutableListOf("داشبورد آماری مدرسه","تعداد دانش‌آموزان: $n")
        while(cr.moveToNext())lines+="فرم ${cr.getInt(0)}: ${cr.getInt(1)} رکورد"
        cr.close()
        root.addView(TextView(this).apply{text=lines.joinToString("\n");textSize=16f})
        addButton("📄 PDF داشبورد"){makePdf("داشبورد آماری",lines)}
        addButton("⬅️ بازگشت"){reports()}
    }

    private fun formPdf(f:FormDef){
        val c=db.query("SELECT createdAt,data FROM records WHERE formNo=? ORDER BY id DESC",arrayOf("${f.no}"))
        val lines=mutableListOf("فرم ${f.no} — ${f.title}")
        while(c.moveToNext()){
            val o=JSONObject(c.getString(1))
            lines+="زمان ثبت: ${c.getString(0)}"
            f.fields.forEach{fd->lines+="${fd.label}: ${o.optString(fd.key)}"}
            lines+="------------------------------"
        }
        c.close();makePdf("فرم ${f.no}",lines)
    }

    private fun makePdf(title:String,lines:List<String>){
        try{
            val d=PdfDocument();var pn=1
            var p=d.startPage(PdfDocument.PageInfo.Builder(842,595,pn).create())
            var y=30f
            val paint=Paint().apply{textSize=13f}
            fun next(){d.finishPage(p);pn++;p=d.startPage(PdfDocument.PageInfo.Builder(842,595,pn).create());y=30f}
            p.canvas.drawText(title,760f,y,paint);y+=26
            lines.forEach{raw->
                raw.replace("\n"," — ").chunked(92).forEach{line->
                    if(y>570)next()
                    p.canvas.drawText(line,820f,y,paint);y+=19
                }
                y+=3
            }
            d.finishPage(p)
            val dir=File(getExternalFilesDir(null),"reports");dir.mkdirs()
            val f=File(dir,"report-${System.currentTimeMillis()}.pdf")
            FileOutputStream(f).use{d.writeTo(it)};d.close()
            toast("PDF ساخته شد:\n${f.absolutePath}")
        }catch(e:Exception){toast("خطای PDF: ${e.message}")}
    }

    private fun backup(u:Uri){
        try{
            val src=getDatabasePath("healthbook.db")
            contentResolver.openOutputStream(u)!!.use{out->src.inputStream().use{it.copyTo(out)}}
            toast("پشتیبان ذخیره شد")
        }catch(e:Exception){toast("خطا: ${e.message}")}
    }
    private fun restore(u:Uri){
        try{
            db.close()
            contentResolver.openInputStream(u)!!.use{inp->getDatabasePath("healthbook.db").outputStream().use{inp.copyTo(it)}}
            db=DB(this);toast("بازیابی انجام شد")
        }catch(e:Exception){toast("خطا: ${e.message}")}
    }

    private fun F(n:Int,t:String,vararg x:FieldDef)=FormDef(n,t,x.toList())
    private fun buildForms():List<FormDef>{
        val a=mutableListOf<FormDef>()
        a+=F(1,"اطلاعات عمومی و پایه مدرسه",
            FieldDef("school","نام مدرسه"),FieldDef("code","کد شناسه مدرسه"),FieldDef("phone","شماره تماس مدرسه"),FieldDef("postal","کد پستی مدرسه"),
            FieldDef("education","دوره تحصیلی: اول ابتدایی / دوم ابتدایی / اول متوسطه / دوم متوسطه"),FieldDef("type","نوع مدرسه: دولتی / غیردولتی / سایر"),FieldDef("ownership","نوع مالکیت: استیجاری / دولتی / شخصی / سایر"),
            FieldDef("building","نوع ساختمان: نوساز / قدیمی / مقاوم‌سازی / چادر، کپر، کانکس، خشت و گل"),FieldDef("area","مساحت مدرسه به متر مربع",numeric=true),FieldDef("floors","تعداد طبقات با احتساب همکف",numeric=true),
            FieldDef("shift","نوبت تحصیل (شیفت)"),FieldDef("shiftStudents","تعداد دانش‌آموزان شیفت غالب",numeric=true),FieldDef("classes","تعداد کل کلاس‌های درس",numeric=true),FieldDef("maxClass","حداکثر تعداد دانش‌آموزان یک کلاس",numeric=true),
            FieldDef("heating","سیستم حرارتی: بخاری گازی / نفتی / شوفاژ / ندارد / سایر"),FieldDef("cooling","سیستم برودتی: کولر گازی / آبی / پنکه / ندارد / سایر"),FieldDef("fireControl","کنترل سیستم گرمایش، سرمایش و برق توسط متخصصان: کنترل می‌شود / نمی‌شود؛ تاریخ"),
            FieldDef("nutritionBase","پایگاه تغذیه سالم: دارد / ندارد؛ اجرای دستورالعمل: بلی / خیر"),FieldDef("water","آبخوری: کافی / ناکافی؛ تعداد؛ کمبود؛ فاصله ۱۵ متری از سرویس بهداشتی: بلی / خیر"),
            FieldDef("wash","روشویی: کافی / ناکافی؛ تعداد؛ کمبود؛ لوله‌کشی/مخزن صابون مایع: دارد / ندارد"),FieldDef("toilet","چشمه توالت: کافی / ناکافی؛ تعداد؛ کمبود"),FieldDef("extinguishers","تعداد کپسول اطفای حریق، نوع A/B/C/D و تعداد کمبود",numeric=true),
            FieldDef("healthRoom","اتاق بهداشت: کامل / ناقص / مشترک / ندارد؛ تجهیزات دارد/ندارد"),FieldDef("mentalHealth","خدمات سلامت روان و مشاوره طبق دستورالعمل: بلی / خیر"),FieldDef("exercise","متوسط فعالیت ورزشی روزانه: کمتر از نیم ساعت / نیم تا یک ساعت / بیشتر از یک ساعت"),FieldDef("organizations","تشکل‌های بهداشتی فعال: سفیران سلامت / سایر"),
            FieldDef("principal","نام و نام خانوادگی مدیر"),FieldDef("principalEdu","مدرک تحصیلی مدیر"),FieldDef("principalField","رشته تحصیلی مدیر"),
            FieldDef("healthMonitor","مراقب سلامت: دارد/ندارد؛ نام، مدرک، رشته، روزهای کاری",multi=true),FieldDef("healthLink","رابط سلامت: دارد/ندارد؛ نام، مدرک، رشته",multi=true),FieldDef("counselor","مشاور: دارد/ندارد؛ نام، مدرک، رشته",multi=true),FieldDef("peTeacher","معلم تربیت بدنی: دارد/ندارد؛ نام، مدرک، رشته",multi=true),FieldDef("servant","خدمتگزار: دارد/ندارد؛ نام، مدرک، رشته؛ گواهی بهداشت/کارت صحت سلامت",multi=true))

        val checklist=listOf(
            "مدرسه با منابع آلاینده محیطی حداقل ۵۰۰ متر فاصله دارد.","مساحت زمین متناسب با تعداد دانش‌آموزان است (حداقل ۶ تا ۸ مترمربع برای هر دانش‌آموز).",
            "پایگاه تغذیه مطابق آیین‌نامه ماده ۱۳ مواد خوردنی، آشامیدنی، آرایشی و بهداشتی است.","افراد دخیل در تهیه و فروش مواد غذایی گواهینامه بهداشت عمومی دارند.","متصدیان پایگاه تغذیه کارت معتبر معاینه پزشکی دارند.","بهداشت فردی و نظافت عمومی محل کار رعایت می‌شود.","افراد دخیل در تهیه و فروش و توزیع مواد غذایی لباس کار روشن دارند.","استعمال دخانیات در محل کار ممنوع و رعایت می‌شود.","کف، دیوار و سقف پایگاه تغذیه مقاوم، بدون درز و شکاف و قابل شستشو و روشن است.","مواد غذایی فاسدشدنی در یخچال/سردخانه مناسب مجهز به دماسنج نگهداری می‌شوند و مواد تاریخ‌گذشته عرضه نمی‌شود.","استفاده از مواد غیراستاندارد برای پیچیدن و بسته‌بندی مواد غذایی ممنوع است.","کیفیت مواد غذایی عرضه‌شده مطابق استانداردها و دستورالعمل‌های وزارت بهداشت است.","مکان مناسب نگهداری شیر در مدرسه وجود دارد.","آشپزخانه مدرسه شبانه‌روزی با ماده ۱۳ مواد خوردنی مطابقت دارد.","مدرسه نمازخانه مناسب از نظر نظافت، محل نگهداری کفش و پوشش کف دارد.","نقشه ساختمانی مدرسه و فضاهای مرتبط با معیارهای بهداشتی مراجع ذی‌ربط منطبق است.","دیوارهای کلاس خشک، بدون درز، صاف و قابل شستشو و رنگ روشن است.","کف کلاس‌ها، راهروها و پله‌ها مقاوم، مسطح، قابل شستشو و غیرلغزنده است.","سقف کلاس‌ها صاف، بدون درز و روشن است.","تابلو کلاس در محل مناسب و حداقل ۲/۲ متر از اولین ردیف دانش‌آموزی فاصله دارد.","فضای کلاس برای هر دانش‌آموز حداقل ۱/۲۵ مترمربع است و ابعاد کلاس در حد مقرر است.","ضوابط ارگونومیکی متناسب با دوره تحصیلی رعایت می‌شود.","پله‌های مشرف به پرتگاه لغزنده نیستند و نرده مناسب دارند.","ارتفاع پله حداکثر ۱۸ سانتی‌متر و عرض حداقل ۳۰ سانتی‌متر و طول حداقل ۱/۳ متر است.","در مدارس استثنایی، نقشه و استقرار کلاس‌ها مطابق ضوابط معلولین است.","درب و پنجره‌های مشرف به خارج برای جلوگیری از ورود حشرات توری دارند.","پنجره‌های طبقه فوقانی حفاظ دارند.","کلاس دانش‌آموزان خردسال در طبقات پایین‌تر ساختمان است.","بالکن و تراس مرتبط با کلاس وجود ندارد.","سالن اجتماعات، کارگاه، آزمایشگاه و فضاهای عمومی مزاحمتی برای کلاس‌ها ایجاد نمی‌کنند.","مساحت اتاق خواب مدارس شبانه‌روزی حدود ۴۰ مترمربع با ۴ تخت دوطبقه است.","حداکثر افراد اتاق عمومی آموزشگاه شبانه‌روزی ۸ نفر است.","کف آزمایشگاه و سطح میزها قابل شستشو و مقاوم به حرارت و مواد شیمیایی است.","آب مصرفی مدرسه با استاندارد ملی ایران ۱۰۱۱ و ۱۰۳۵ و تأیید وزارت بهداشت مطابقت دارد.","حجم مخزن آب، در صورت وجود، پاسخگوی تعداد دانش‌آموزان و حداقل ۱۵ لیتر برای هر دانش‌آموز است.","در مدرسه شبانه‌روزی حداقل ۱۰۰ لیتر آب برای هر دو نفر در نظر گرفته شده است.","آبخوری شرایط بهداشتی، کف و دیوار قابل شستشو و دفع بهداشتی و شیب مناسب دارد؛ تعداد آبخوری ثبت شود.","ارتفاع شیر آبخوری متناسب با سن دانش‌آموزان ۷۵ تا ۱۰۰ سانتی‌متر است.","آبخوری خارج از سرویس بهداشتی و حداقل ۱۵ متر فاصله دارد.","آبخوری عمومی شیر مناسب دارد؛ حداقل یک شیر برای هر ۴۵ دانش‌آموز.","تعداد توالت‌ها به ازای هر ۴۰ نفر یک چشمه است.","تعداد روشویی‌ها به ازای هر ۶۰ نفر یک چشمه است.","روشویی‌ها شرایط بهداشتی دارند.","تعداد کل توالت‌ها و تعداد توالت‌های بهداشتی ثبت شده است.","دیوار توالت حداقل تا ارتفاع ۱۵۰ سانتی‌متر قابل شستشو است.","توالت‌ها دارای چاه فاضلاب/مخزن یا اتصال به شبکه جمع‌آوری فاضلاب هستند.","اتاقک توالت دارای نور، جریان هوا، دیوار، سقف و در است.","کف توالت شیب مناسب و قابل شستشو دارد و سره سالم و قابل شستشو است؛ آب و شلنگ در دسترس است.","ارتفاع روشویی‌ها متناسب با سن دانش‌آموز ۶۰ تا ۷۵ سانتی‌متر است.","لوله‌کشی صابون مایع موجود و در دسترس است.","دفع فاضلاب مطابق استانداردهای موجود است و در مناطق فاقد شبکه، دفع به روش بهداشتی انجام می‌شود؛ حجم سپتیک/چاه جاذب متناسب است."
        )
        val f2fields = mutableListOf(FieldDef("date","تاریخ تکمیل"),FieldDef("monitor","نام و نام خانوادگی مراقب سلامت"),FieldDef("principal","نام و نام خانوادگی مدیر آموزشگاه"))
        checklist.forEachIndexed{i,x->f2fields += FieldDef("item${i+1}","${i+1}. $x — نتیجه بازدید/مطابقت")}
        f2fields += FieldDef("signature","مهر و امضاء",multi=true)
        a += FormDef(2,"پیگیری آیین‌نامه بهداشت محیط مدارس",f2fields)

        a+=F(3,"ثبت خودارزیابی پایگاه تغذیه سالم مدارس",FieldDef("date","تاریخ"),FieldDef("result","نتیجه خودارزیابی پایگاه تغذیه سالم",multi=true),FieldDef("actions","اقدامات اصلاحی و پیگیری",multi=true))
        a+=F(4,"ثبت زمانبندی کلاس‌های سفیران سلامت",FieldDef("date","تاریخ"),FieldDef("day","روز"),FieldDef("time","ساعت"),FieldDef("trained","تعداد افراد آموزش دیده",numeric=true),FieldDef("topic","موضوع آموزش"))
        a+=F(5,"اسامی و فعالیت سفیران سلامت",FieldDef("name","نام و نام خانوادگی"),FieldDef("class","کلاس"),FieldDef("actions","اقدامات سفیر سلامت",multi=true))
        a+=F(6,"آمار و اطلاعات برنامه سفیران سلامت",FieldDef("pG","ابتدایی دختر",numeric=true),FieldDef("pB","ابتدایی پسر",numeric=true),FieldDef("m1G","متوسطه اول دختر",numeric=true),FieldDef("m1B","متوسطه اول پسر",numeric=true),FieldDef("m2G","متوسطه دوم دختر",numeric=true),FieldDef("m2B","متوسطه دوم پسر",numeric=true),FieldDef("totalG","جمع کل دختر",numeric=true),FieldDef("totalB","جمع کل پسر",numeric=true))
        a+=F(7,"برگزیدگان مدرسه‌ای جشنواره سفیران سلامت",FieldDef("name","نام و نام خانوادگی"),FieldDef("grade","پایه"),FieldDef("rank","رتبه"),FieldDef("field","رشته"))
        a+=F(8,"ثبت جلسات آموزشی مدرسه",FieldDef("date","تاریخ"),FieldDef("topic","موضوع کلاس آموزشی"),FieldDef("target","گروه هدف"),FieldDef("trained","تعداد افراد آموزش دیده",numeric=true),FieldDef("trainer","نام آموزش دهنده"),FieldDef("org","سمت سازمانی/نام سازمان"),FieldDef("type","نوع آموزش: حضوری / غیرحضوری / برخط"),FieldDef("tool","نوع وسیله کمک آموزشی استفاده شده"))
        a+=F(9,"ثبت فعالیت‌های آموزشی مدرسه",FieldDef("date","تاریخ"),FieldDef("topic","موضوع آموزش"),FieldDef("contest","برگزاری مسابقه"),FieldDef("show","اجرای نمایش"),FieldDef("exhibition","برپایی نمایشگاه"),FieldDef("tools","وسیله کمک آموزشی: پوستر/تراکت، بروشور، روزنامه دیواری، ویدیو، شاد، سایر"))
        a+=F(10,"اطلاعات و سوابق بهداشتی دانش‌آموز",FieldDef("student","نام و نام خانوادگی دانش‌آموز"),FieldDef("dob","تاریخ تولد"),FieldDef("familyHistory","سوابق و وضعیت بهداشتی دانش‌آموز/خانواده",multi=true),FieldDef("conditions","بیماری‌ها و مشکلات بهداشتی ثبت‌شده",multi=true),FieldDef("vaccination","وضعیت واکسیناسیون/موارد قابل پیگیری",multi=true),FieldDef("allergy","حساسیت‌ها/موارد نیازمند توجه",multi=true),FieldDef("followup","اقدامات و پیگیری",multi=true),FieldDef("parentSign","امضای ولی",multi=true))
        a+=F(11,"دانش‌آموزان مبتلا به بیماری‌های خاص/نیازمند مراقبت ویژه",FieldDef("student","نام و نام خانوادگی"),FieldDef("class","کلاس"),FieldDef("disease","بیماری"),FieldDef("care","مراقبت‌های ویژه و اقدامات پیگیری",multi=true),FieldDef("referral","نتیجه ارجاع"))
        a+=F(12,"دانش‌آموزان دارای اختلال رفتاری",FieldDef("name","نام و نام خانوادگی"),FieldDef("class","کلاس"),FieldDef("disorder","نوع اختلال"),FieldDef("actions","اقدامات و پیگیری‌های انجام شده",multi=true))
        a+=F(13,"دانش‌آموزان مبتلا به بیماری‌های واگیر در طی سال",FieldDef("name","نام و نام خانوادگی"),FieldDef("class","کلاس"),FieldDef("disease","بیماری واگیر"),FieldDef("date","تاریخ"),FieldDef("actions","اقدامات و پیگیری",multi=true))
        a+=F(14,"مکمل‌یاری آهن و ویتامین D (ویژه مدارس متوسطه دخترانه)",FieldDef("sessions","تعداد جلسات آموزشی والدین و دانش‌آموزان",numeric=true),FieldDef("contra","تعداد دانش‌آموزان دارای منع مصرف",numeric=true),FieldDef("covered","تعداد دانش‌آموزان تحت پوشش برنامه",numeric=true),FieldDef("monitor","مراقب سلامت",numeric=true),FieldDef("education","کارکنان آموزش و پرورش",numeric=true),FieldDef("network","شبکه بهداشت",numeric=true))
        a+=F(15,"پیگیری واکسیناسیون پایه اول و دهم",FieldDef("grade","پایه: اول / دهم"),FieldDef("coverage","درصد پوشش واکسیناسیون",numeric=true),FieldDef("referred","تعداد دانش‌آموزان ارجاع شده",numeric=true),FieldDef("incomplete","تعداد دانش‌آموزان با واکسیناسیون ناقص",numeric=true),FieldDef("total","تعداد کل دانش‌آموزان",numeric=true),FieldDef("vaccinated","تعداد کل دانش‌آموزان واکسینه شده",numeric=true))
        a+=F(16,"ثبت مشخصات دانش‌آموزان آلوده به پدیکلوز",FieldDef("student","نام و نام خانوادگی"),FieldDef("class","کلاس"),FieldDef("date","تاریخ"),FieldDef("season","فصل"),FieldDef("status","ابتلا / عود / درمان"),FieldDef("treatment","درمان و پیگیری",multi=true))
        a+=F(17,"آمار سالیانه معاینات پدیکلوزیس سر",FieldDef("schoolType","نوع مدرسه: شهری / روستایی"),FieldDef("level","مقطع: ابتدایی / متوسطه اول / متوسطه دوم"),FieldDef("population","جمعیت دانش‌آموزان",numeric=true),FieldDef("autumnExamG","پاییز معاینه دختر",numeric=true),FieldDef("autumnExamB","پاییز معاینه پسر",numeric=true),FieldDef("autumnCaseG","پاییز ابتلا دختر",numeric=true),FieldDef("autumnCaseB","پاییز ابتلا پسر",numeric=true),FieldDef("winterExamG","زمستان معاینه دختر",numeric=true),FieldDef("winterExamB","زمستان معاینه پسر",numeric=true),FieldDef("winterCaseG","زمستان ابتلا دختر",numeric=true),FieldDef("winterCaseB","زمستان ابتلا پسر",numeric=true),FieldDef("springExamG","بهار معاینه دختر",numeric=true),FieldDef("springExamB","بهار معاینه پسر",numeric=true),FieldDef("springCaseG","بهار ابتلا دختر",numeric=true),FieldDef("springCaseB","بهار ابتلا پسر",numeric=true),FieldDef("recurrenceG","موارد عود دختر",numeric=true),FieldDef("recurrenceB","موارد عود پسر",numeric=true),FieldDef("packages","بسته‌های آموزشی توزیع شده",numeric=true),FieldDef("trainedStudents","آموزش‌دیدگان دانش‌آموزان",numeric=true),FieldDef("trainedStaff","آموزش‌دیدگان کارکنان",numeric=true),FieldDef("trainedParents","آموزش‌دیدگان والدین",numeric=true),FieldDef("trainedTotal","جمع آموزش‌دیدگان",numeric=true))
        a+=F(18,"ثبت حوادث و سوانح",FieldDef("date","تاریخ مراجعه/اعلام/پیگیری"),FieldDef("name","نام و نام خانوادگی"),FieldDef("grade","پایه تحصیلی"),FieldDef("place","محل حادثه: داخل مدرسه / بین خانه و مدرسه"),FieldDef("accident","نوع حادثه: افتادن/لیزخوردن، ضربه با شی، سقوط از بلندی، تصادف نقلیه، سوختگی، سایر"),FieldDef("injury","نوع آسیب"),FieldDef("result","نتیجه حادثه"),FieldDef("intervention","مداخلات مورد نیاز: اقدامات اولیه/ارجاع فوری، درمان سرپایی، فوت، نقص عضو، غیبت بیش از دو..."),FieldDef("description","شرح حادثه",multi=true),FieldDef("referral","نتیجه ارجاع"),FieldDef("followup","مسئول پیگیری کننده / مهر و امضای مدیر مدرسه",multi=true))
        a+=F(19,"ثبت معاینات مقدماتی دانش‌آموزان",FieldDef("class","کلاس"),FieldDef("date","تاریخ"),FieldDef("name","نام و نام خانوادگی"),FieldDef("dob","تاریخ تولد روز/ماه/سال"),FieldDef("age","سن",numeric=true),FieldDef("height","قد (cm)",numeric=true),FieldDef("weight","وزن (kg)",numeric=true),FieldDef("bmi","BMI"),FieldDef("heightAge","قد به سن / صدک"),FieldDef("weightBmi","وزن/BMI به سن / صدک"),FieldDef("visionR","بینایی چشم راست"),FieldDef("visionL","بینایی چشم چپ"),FieldDef("visionBoth","بینایی هر دو چشم"),FieldDef("hearingR","شنوایی گوش راست"),FieldDef("hearingL","شنوایی گوش چپ"),FieldDef("dentalPermanent","دهان و دندان — دندان دائمی: پرشده/کشیده/پوسیده",multi=true),FieldDef("dentalMilk","دهان و دندان — دندان شیری: پرشده/کشیده/پوسیده",multi=true),FieldDef("gum","لثه"),FieldDef("posture","اختلالات قامتی"),FieldDef("nutrition","کمبودهای تغذیه‌ای"))
        a+=F(20,"ثبت و پیگیری ارجاعات دانش‌آموزان",FieldDef("name","نام و نام خانوادگی"),FieldDef("class","کلاس"),FieldDef("examDate","تاریخ معاینه"),FieldDef("disorder","نوع اختلال"),FieldDef("refDate","تاریخ ارجاع"),FieldDef("result","نتیجه ارجاع: سالم / بیماری تأیید / عدم پاسخ / درمان شده با ذکر درمان"),FieldDef("actions","اقدامات و خدمات حمایتی: مشاوره دانش‌آموز / اولیای مدرسه / والدین / عینک / سمعک / سایر",multi=true))
        a+=F(21,"ثبت اطلاعات وارنیش فلورایدتراپی",FieldDef("grade","پایه: اول تا ششم"),FieldDef("total","تعداد کل دانش‌آموزان",numeric=true),FieldDef("first","نوبت اول وارنیش",numeric=true),FieldDef("second","نوبت دوم وارنیش",numeric=true))
        a+=F(22,"ثبت نتایج سالانه معاینات غربالگری دانش‌آموزان",FieldDef("grade","پایه/کلاس"),FieldDef("date","تاریخ"),FieldDef("examined","تعداد معاینه‌شده",numeric=true),FieldDef("normal","سالم",numeric=true),FieldDef("abnormal","نیازمند پیگیری/ارجاع",numeric=true),FieldDef("results","نتایج و یافته‌ها",multi=true),FieldDef("summary","خلاصه آماری و اقدامات پیگیری",multi=true))
        a+=F(23,"جلب مشارکت خیرین سلامت، اولیاء، کارکنان، سازمان‌ها و ...",FieldDef("name","نام و نام خانوادگی مشارکت‌کننده"),FieldDef("participation","نوع مشارکت"),FieldDef("phone","شماره تماس"),FieldDef("organization","سازمان و دستگاه"),FieldDef("category","دسته: کارکنان / خیرین سلامت / اولیا"),FieldDef("student","نام دانش‌آموز"),FieldDef("grade","پایه"),FieldDef("class","کلاس"))
        a+=F(24,"جلب مشارکت اولیاء پزشک و پیراپزشک",FieldDef("parent","نام و نام خانوادگی ولی"),FieldDef("student","نام و نام خانوادگی دانش‌آموز"),FieldDef("specialty","تخصص و رشته تحصیلی"),FieldDef("participation","نوع مشارکت: معاینه رایگان / درمان رایگان / اقلام بهداشتی / سایر"),FieldDef("phone","شماره تماس"))
        a+=F(25,"ارزیابی فعالیت‌های زیست محیطی آموزشگاه",FieldDef("sessions","تعداد جلسات آموزش زیست محیطی برگزار شده",numeric=true),FieldDef("occasions","تعداد مناسبت‌های زیست محیطی برگزار شده (روز هوای پاک، زمین پاک، درختکاری)",numeric=true),FieldDef("projects","اجرای طرح‌های محیط زیستی: همیار طبیعت / خانه محیط زیست",multi=true),FieldDef("waste","اجرای طرح تفکیک زباله خشک و تر"),FieldDef("innovation","ابتکارات و خلاقیت‌ها",multi=true),FieldDef("notes","توضیحات",multi=true))
        a+=F(26,"ثبت گزارش فوت",FieldDef("name","نام و نام خانوادگی"),FieldDef("grade","پایه تحصیلی"),FieldDef("age","سن",numeric=true),FieldDef("cause","علت فوت"),FieldDef("date","تاریخ فوت"),FieldDef("notes","توضیحات",multi=true))
        a+=F(27,"صورتجلسه کمیته سلامت و ایمنی",FieldDef("date","تاریخ"),FieldDef("members","اعضای حاضر",multi=true),FieldDef("agenda","دستور جلسه",multi=true),FieldDef("decisions","مصوبات",multi=true),FieldDef("followup","مسئول و زمان پیگیری",multi=true),FieldDef("signatures","مهر و امضا",multi=true))
        a+=F(28,"نمون برگ ارجاع دانش‌آموز",FieldDef("date","تاریخ"),FieldDef("student","نام و نام خانوادگی دانش‌آموز"),FieldDef("gradeClass","پایه / کلاس"),FieldDef("reason","علت ارجاع",multi=true),FieldDef("service","مرکز/خدمت پیشنهادی"),FieldDef("result","نتیجه ارجاع و پیگیری",multi=true))
        a+=F(29,"نمون برگ ارزشیابی عملکرد مراقبین سلامت",FieldDef("date","تاریخ"),FieldDef("monitor","نام و نام خانوادگی مراقب سلامت"),FieldDef("evaluator","نام و نام خانوادگی ارزیاب"),FieldDef("criteria","معیارها و شرح ارزشیابی",multi=true),FieldDef("score","امتیاز/نتیجه"),FieldDef("strengths","نقاط قوت",multi=true),FieldDef("improve","موارد نیازمند بهبود",multi=true),FieldDef("signatures","امضا و تأیید",multi=true))
        return a
    }
}
