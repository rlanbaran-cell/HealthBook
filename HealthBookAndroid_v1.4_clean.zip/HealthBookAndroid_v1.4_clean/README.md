# HealthBook Android v1.4

دفتر الکترونیک مراقب سلامت — نسخه 1.4.0

## ساختار

- `app/src/main/java/com/healthbook/app/MainActivity.kt` — منطق اصلی برنامه
- `app/src/main/res/` — منابع Android
- `app/build.gradle.kts` — تنظیمات ماژول
- `build.gradle.kts` — تنظیمات پروژه
- `settings.gradle.kts` — تعریف پروژه و repositoryها
- `gradle/wrapper/gradle-wrapper.properties` — تنظیم Gradle Wrapper

## مشخصات فعلی

- Android Gradle Plugin: 8.5.2
- Kotlin: 1.9.24
- Compile SDK: 35
- Min SDK: 24
- Target SDK: 35
- Version: 1.4.0
- پایگاه داده: SQLite
- خروجی PDF و Backup/Restore
- ورود گروهی دانش‌آموزان از CSV/XLSX
- فرم‌های 1 تا 29

## ساخت در Termux

این ZIP شامل سورس مرتب‌شده است و فایل‌های build تولیدشده داخل آن نیستند.

پس از انتقال و استخراج:

```bash
cd ~/downloads/HealthBookAndroid_v1.4
bash build-termux.sh
```

اگر `build-termux.sh` در سیستم شما از قبل وجود دارد، می‌توانید آن را در ریشه پروژه قرار دهید؛ سورس برنامه به آن وابسته نیست.
